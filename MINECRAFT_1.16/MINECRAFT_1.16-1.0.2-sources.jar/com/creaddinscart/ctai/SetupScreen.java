package com.creaddinscart.ctai;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2585;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public final class SetupScreen extends class_437 {
    private static final int FIELD_HEIGHT = 20;
    private static final int LABEL_WIDTH = 118;
    private static final int GAP = 8;
    private static final int MARGIN = 8;
    private static final double[] SCALE_STEPS = {0.70, 0.85, 1.0, 1.15, 1.30, 1.50};

    private final class_437 parent;

    private Layout layout;
    private class_342 botNameField;
    private class_342 apiKeyField;
    private class_342 apiHostField;
    private class_342 modelField;
    private class_342 promptField;
    private class_342 temperatureField;
    private class_342 maxTokensField;
    private class_342 timeoutField;

    private class_4185 compatibilityButton;
    private class_4185 agentButton;
    private class_4185 uiScaleButton;

    private int compatibilityIndex;
    private String status = "";
    private boolean statusError = false;

    public SetupScreen(class_437 parent) {
        super(new class_2585("CREADDINSCART AI BOT - Setup"));
        this.parent = parent;
        CTAIConfig config = CTAIConfig.get();
        this.compatibilityIndex = AiCompatibility.fromName(config.compatibilityMode).ordinal();
    }

    @Override
    protected void method_25426() {
        CTAIConfig config = CTAIConfig.get();
        this.layout = computeLayout();
        int rowY = this.layout.startY;

        this.botNameField = addField(rowY, config.botName, 80);
        rowY += this.layout.rowSpacing;
        this.apiKeyField = addField(rowY, config.apiKey, 400);
        rowY += this.layout.rowSpacing;
        this.apiHostField = addField(rowY, config.apiHost, 200);
        rowY += this.layout.rowSpacing;
        this.modelField = addField(rowY, config.model, 200);
        rowY += this.layout.rowSpacing;
        this.promptField = addField(rowY, config.systemPrompt, 400);
        rowY += this.layout.rowSpacing;
        this.temperatureField = addField(rowY, Double.toString(config.temperature), 16);
        rowY += this.layout.rowSpacing;
        this.maxTokensField = addField(rowY, Integer.toString(config.maxTokens), 8);
        rowY += this.layout.rowSpacing;
        this.timeoutField = addField(rowY, Integer.toString(config.timeoutSeconds), 6);
        rowY += this.layout.rowSpacing;

        List<class_4185> compatRow = addButtonRow(rowY, new String[]{compatibilityLabel()}, i -> {
            this.compatibilityIndex = (this.compatibilityIndex + 1) % AiCompatibility.values().length;
            updateButtonLabels();
        }, 240);
        this.compatibilityButton = compatRow.get(0);
        rowY += this.layout.rowSpacing;

        List<class_4185> agentRow = addButtonRow(rowY, new String[]{agentLabel()}, i -> {
            CTAIConfig.get().agentEnabled = !CTAIConfig.get().agentEnabled;
            CTAIConfig.save();
            updateButtonLabels();
        }, 240);
        this.agentButton = agentRow.get(0);
        rowY += this.layout.rowSpacing + 4;

        List<class_4185> tools = addButtonRow(rowY,
                new String[]{"Scan Models", "Models", "Test Connection", scaleLabel()},
                i -> {
                    if (i == 0) {
                        scanModels();
                    } else if (i == 1) {
                        cycleModel();
                    } else if (i == 2) {
                        testConnection();
                    } else {
                        cycleScale();
                    }
                }, 132);
        this.uiScaleButton = tools.get(3);
        rowY += 24;

        addButtonRow(rowY, new String[]{"Save & Continue", "Cancel"},
                i -> {
                    if (i == 0) {
                        save();
                    } else {
                        method_25419();
                    }
                }, 160);

        updateButtonLabels();
        if (this.botNameField != null) {
            this.method_20085(this.botNameField);
        }
    }

    private Layout computeLayout() {
        double scale = CTAIConfig.get().uiScale;
        if (scale <= 0) {
            scale = 1.0;
        }
        int fieldWidth = clamp((int) (this.field_22789 * 0.34 * scale), 120, 300);
        int contentWidth = LABEL_WIDTH + GAP + fieldWidth;
        int left = Math.max(MARGIN, (this.field_22789 - contentWidth) / 2);
        int fieldX = left + LABEL_WIDTH + GAP;
        int startY = 26;

        int rows = 10;
        int bottomReserve = 24 + 24 + 20 + 16;
        int available = this.field_22790 - startY - bottomReserve;
        int rowSpacing = clamp((int) ((available / (double) rows) * scale), 12, 26);
        if (startY + rows * rowSpacing + bottomReserve > this.field_22790) {
            rowSpacing = Math.max(11, (this.field_22790 - startY - bottomReserve) / rows);
        }
        return new Layout(left, fieldX, fieldWidth, rowSpacing, startY);
    }

    private class_342 addField(int y, String value, int maxLength) {
        class_342 field = new class_342(this.field_22793, this.layout.fieldX, y,
                this.layout.fieldWidth, FIELD_HEIGHT, new class_2585(""));
        field.method_1852(value == null ? "" : value);
        field.method_1880(maxLength);
        this.method_25411(field);
        return field;
    }

    private List<class_4185> addButtonRow(int y, String[] labels, java.util.function.Consumer<Integer> action, int maxWidth) {
        int gap = 6;
        int buttonWidth = clamp((this.field_22789 - MARGIN * 2 - gap * (labels.length - 1)) / labels.length, 66, maxWidth);
        int totalWidth = buttonWidth * labels.length + gap * (labels.length - 1);
        int startX = Math.max(MARGIN, (this.field_22789 - totalWidth) / 2);
        List<class_4185> buttons = new ArrayList<>();
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            class_4185 button = new class_4185(startX + i * (buttonWidth + gap), y, buttonWidth, FIELD_HEIGHT,
                    new class_2585(labels[i]), b -> action.accept(index));
            this.method_25411(button);
            buttons.add(button);
        }
        return buttons;
    }

    private void updateButtonLabels() {
        if (this.compatibilityButton != null) {
            this.compatibilityButton.method_25355(new class_2585(compatibilityLabel()));
        }
        if (this.agentButton != null) {
            this.agentButton.method_25355(new class_2585(agentLabel()));
        }
        if (this.uiScaleButton != null) {
            this.uiScaleButton.method_25355(new class_2585(scaleLabel()));
        }
    }

    private String compatibilityLabel() {
        AiCompatibility mode = AiCompatibility.values()[this.compatibilityIndex];
        return "Compatibility: " + mode.getDisplayName();
    }

    private String agentLabel() {
        return "Agent: " + (CTAIConfig.get().agentEnabled ? "ON" : "OFF");
    }

    private String scaleLabel() {
        return "UI " + Math.round(CTAIConfig.get().uiScale * 100) + "%";
    }

    private void cycleScale() {
        readFields();
        double current = CTAIConfig.get().uiScale;
        int index = 0;
        for (int i = 0; i < SCALE_STEPS.length; i++) {
            if (Math.abs(SCALE_STEPS[i] - current) < 0.01) {
                index = i;
                break;
            }
            if (SCALE_STEPS[i] > current) {
                index = i;
                break;
            }
            index = i;
        }
        CTAIConfig.get().uiScale = SCALE_STEPS[(index + 1) % SCALE_STEPS.length];
        CTAIConfig.save();
        this.field_22787.method_1507(new SetupScreen(this.parent));
    }

    private void cycleModel() {
        List<String> models = CTAIConfig.get().availableModels;
        if (models == null || models.isEmpty()) {
            setStatus("No scanned models. Click Scan Models first.", true);
            return;
        }
        String current = this.modelField.method_1882().trim();
        int index = models.indexOf(current);
        index = (index + 1) % models.size();
        this.modelField.method_1852(models.get(index));
        setStatus("Model " + (index + 1) + "/" + models.size() + ": " + models.get(index), false);
    }

    private void readFields() {
        if (this.botNameField == null) {
            return;
        }
        CTAIConfig config = CTAIConfig.get();
        config.botName = this.botNameField.method_1882().trim();
        config.apiKey = this.apiKeyField.method_1882().trim();
        config.apiHost = this.apiHostField.method_1882().trim();
        config.model = this.modelField.method_1882().trim();
        config.systemPrompt = this.promptField.method_1882().trim();
        config.compatibilityMode = AiCompatibility.values()[this.compatibilityIndex].name();
    }

    private void save() {
        readFields();
        CTAIConfig config = CTAIConfig.get();
        AiCompatibility mode = AiCompatibility.values()[this.compatibilityIndex];

        if (config.botName.isEmpty() || config.apiHost.isEmpty()) {
            setStatus("Bot name and API host are required.", true);
            return;
        }
        String keyIssue = CTAIConfig.keyIssue(config.apiKey, mode);
        if (keyIssue != null) {
            setStatus(keyIssue, true);
            return;
        }
        if (!config.apiHost.startsWith("http://") && !config.apiHost.startsWith("https://")) {
            setStatus("API host must start with http:// or https://", true);
            return;
        }
        if (config.model.isEmpty()) {
            config.model = mode.getDefaultModel();
        }

        try {
            config.temperature = Double.parseDouble(this.temperatureField.method_1882().trim());
        } catch (NumberFormatException e) {
            config.temperature = 0.7;
        }
        try {
            config.maxTokens = Integer.parseInt(this.maxTokensField.method_1882().trim());
        } catch (NumberFormatException e) {
            config.maxTokens = 512;
        }
        try {
            config.timeoutSeconds = Integer.parseInt(this.timeoutField.method_1882().trim());
        } catch (NumberFormatException e) {
            config.timeoutSeconds = 30;
        }
        config.temperature = Math.max(0.0, Math.min(2.0, config.temperature));
        config.maxTokens = Math.max(1, config.maxTokens);
        config.timeoutSeconds = Math.max(5, config.timeoutSeconds);

        config.completed = true;
        CTAIConfig.save();
        this.field_22787.method_1507(this.parent);
    }

    private void testConnection() {
        readFields();
        final CTAIConfig config = CTAIConfig.get();
        AiCompatibility mode = AiCompatibility.values()[this.compatibilityIndex];
        String keyIssue = CTAIConfig.keyIssue(config.apiKey, mode);
        if (keyIssue != null) {
            setStatus(keyIssue, true);
            return;
        }
        if (config.model.isEmpty()) {
            config.model = mode.getDefaultModel();
        }

        setStatus("Testing " + mode.getDisplayName() + " with key " + CTAIConfig.maskKey(config.apiKey) + " ...", false);
        Thread worker = new Thread(() -> {
            try {
                String answer = AiClient.testConnection(config);
                String preview = answer.length() > 40 ? answer.substring(0, 40) + "..." : answer;
                this.field_22787.execute(() ->
                        setStatus("Connection OK - provider replied: " + preview.replaceAll("\\s+", " "), false));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                this.field_22787.execute(() -> setStatus(message, true));
            }
        }, "ctai-test-worker");
        worker.setDaemon(true);
        worker.start();
    }

    private void scanModels() {
        readFields();
        final CTAIConfig config = CTAIConfig.get();
        String keyIssue = CTAIConfig.keyIssue(config.apiKey, AiCompatibility.values()[this.compatibilityIndex]);
        if (keyIssue != null) {
            setStatus(keyIssue, true);
            return;
        }

        setStatus("Scanning models at " + config.apiHost + " ...", false);
        Thread worker = new Thread(() -> {
            try {
                List<String> models = AiClient.listModels(config);
                CTAIConfig.get().availableModels = models;
                CTAIConfig.save();
                this.field_22787.execute(() -> {
                    if (models.isEmpty()) {
                        setStatus("Scan finished but no models were returned.", true);
                    } else {
                        setStatus("Found " + models.size() + " models. Use Models button to cycle.", false);
                    }
                });
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                this.field_22787.execute(() -> setStatus(message, true));
            }
        }, "ctai-model-scan-worker");
        worker.setDaemon(true);
        worker.start();
    }

    private void setStatus(String message, boolean error) {
        this.statusError = error;
        String clean = message == null ? "" : message.replaceAll("\\s+", " ").trim();
        int max = Math.max(30, this.field_22789 / 6);
        if (clean.length() > max) {
            clean = clean.substring(0, max - 3) + "...";
        }
        this.status = clean;
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(this.parent);
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float partialTick) {
        this.method_25420(matrices);
        super.method_25394(matrices, mouseX, mouseY, partialTick);
        method_27534(matrices, this.field_22793, this.field_22785, this.field_22789 / 2, 10, 0xFFFFFF);

        String[] labels = {"Bot Name", "API Key", "API Host", "Model", "System Prompt",
                "Temperature", "Max Tokens", "Timeout (s)"};
        int y = this.layout.startY;
        for (String label : labels) {
            method_25303(matrices, this.field_22793, label, this.layout.labelX, y + 5, 0xFFFFFF);
            y += this.layout.rowSpacing;
        }
        method_25303(matrices, this.field_22793, "Compatibility", this.layout.labelX, y + 5, 0xFFFFFF);
        y += this.layout.rowSpacing;
        method_25303(matrices, this.field_22793, "Agent", this.layout.labelX, y + 5, 0xFFFFFF);

        int statusY = Math.min(this.field_22790 - 14, y + this.layout.rowSpacing + 32);
        method_25300(matrices, this.field_22793, this.status, this.field_22789 / 2, statusY,
                this.statusError ? 0xFF5555 : 0x55FF55);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static final class Layout {
        final int labelX;
        final int fieldX;
        final int fieldWidth;
        final int rowSpacing;
        final int startY;

        Layout(int labelX, int fieldX, int fieldWidth, int rowSpacing, int startY) {
            this.labelX = labelX;
            this.fieldX = fieldX;
            this.fieldWidth = fieldWidth;
            this.rowSpacing = rowSpacing;
            this.startY = startY;
        }
    }
}
