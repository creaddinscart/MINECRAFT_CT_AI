package com.creaddinscart.ctai.mixin;

import com.creaddinscart.ctai.CTAIConfig;
import com.creaddinscart.ctai.SetupScreen;
import net.minecraft.class_2585;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(class_2585 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void ctai$setupGate(CallbackInfo ci) {
        if (!CTAIConfig.get().completed) {
            this.field_22787.execute(() -> this.field_22787.method_1507(new SetupScreen(this)));
        }
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void ctai$addSetupButton(CallbackInfo ci) {
        this.method_25411(new class_4185(this.field_22789 - 96, this.field_22790 - 28, 88, 20,
                new class_2585("CT AI Setup"), button -> this.field_22787.method_1507(new SetupScreen(this))));
    }
}
